
/*the following is my answer  */
#include <iostream>
using namespace std;
int main()
{
	int k=6, i = k + 1;
	cout << i++ << endl;
	int a = 1;
	cout << a++ << endl;
	cout << "Welcome to C++!" << endl;
	return 0;
}
