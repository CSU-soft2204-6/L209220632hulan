/*the following is my program to count letters of differernt types of data  */

#include <iostream>
using namespace std;
int main()
{
	cout << "character length:" << sizeof(char) << endl;
	cout << "integer length:" << sizeof(int) << endl;
	cout << "short length:" << sizeof(short) << endl;
	cout << "long length:" << sizeof(long) << endl;
	cout << "float length" << sizeof(float) << endl;
	cout << "double length:" << sizeof(double) << endl;
	cout << "long double length:" << sizeof(long double) << endl;
	cout << "wchar_t length:" << sizeof(wchar_t) << endl;
    return 0;
}
